import os
from PIL import Image, ImageOps
import streamlit as st
import numpy as np
import cv2
from tensorflow.keras.utils import to_categorical as tcg
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense ,Dropout,Flatten
from tensorflow.keras import models

st.set_option('deprecation.showfileUploaderEncoding', False)

def load_mnist():
	model = models.load_model(filepath='E:\ml2\mnist_model')
	return model

def load_cifar_ff():
	model = models.load_model(filepath='E:\ml2\cifar_ff')
	return model

def load_cifar_cnn():
	model = models.load_model(filepath='E:\ml2\cifar_cnn')
	return model


def test_gui_mnist(model):
	upload_file = st.file_uploader("Choose an Image",type=["jpg","jpeg","png"])
	if upload_file is not None:
		man_inp=Image.open(upload_file)
		man_inp=cv2.cvtColor(np.array(man_inp),cv2.COLOR_RGB2GRAY)
		#st.write(man_inp)
		#man_inp = cv2.imdecode(np.fromstring(request.files[upload_file].read(), np.uint8), cv2.IMREAD_UNCHANGED)
		man_inp =cv2.resize(man_inp,(28,28))
		inp_arr = np.array(man_inp)
		inp_arr=inp_arr.reshape(inp_arr.shape[0],inp_arr.shape[0],1).astype('float32')/255
		x=np.array([inp_arr])

		st.image(man_inp,caption = 'Uploaded Image',width=10,use_column_width=True)
		st.write("")

		label = model.predict_classes(x)
		st.write("Predicted class is",label[0])

def test_gui_cifar(model):
	labels =  ['airplane', 'car', 'bird', 'cat', 'deer','dog', 'frog', 'horse', 'ship', 'truck']
	upload_file = st.file_uploader("Choose an Image",type=["jpg","jpeg","png"])
	if upload_file is not None:
		man_inp=Image.open(upload_file)
		man_inp=cv2.cvtColor(np.array(man_inp))
		st.write("input array shape",np.array(man_inp).shape)
		size=(32,32)
		man_inp = ImageOps.fit(man_inp,size,Image.ANTIALIAS)
		#man_inp =cv2.resize(man_inp,(32,32))
		inp_arr = np.asarray(man_inp)
		inp_arr=inp_arr.reshape(inp_arr.shape[0],inp_arr.shape[1],inp_arr.shape[2],3).astype('float32')/255
		st.write("Image shape is",img.shape)
		x=np.array([inp_arr])

		st.image(man_inp,caption = 'Uploaded Image',width=10,use_column_width=True)
		st.write("")
		label = model.predict_classes(x)
		st.write("Predicted class is",labels[label[0]])

display = ("CIFAR_FF", "CIFAR_CNN", "MNIST")
options = list(range(len(display)))
value = st.selectbox("CHOOSE ONE OF THEM", options, format_func=lambda x: display[x])
st.write(value)

if(value==0):
	model=load_cifar_ff()
	test_gui_cifar(model)

elif(value==1):
	model=load_cifar_cnn()
	test_gui_cifar(model)

elif(value==2):
	model=load_mnist()
	test_gui_mnist(model)