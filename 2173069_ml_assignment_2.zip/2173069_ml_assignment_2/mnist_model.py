from tensorflow.keras.datasets import mnist
from matplotlib import pyplot as plt
from tensorflow.keras.utils import to_categorical as tcg
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense ,Dropout,Flatten
from tensorflow.keras import models

(xtr,ytr),(xte,yte)=mnist.load_data()

xte=xte.reshape(xte.shape[0],xte.shape[1],xte.shape[2],1).astype('float32')/255
xtr=xtr.reshape(xtr.shape[0],xtr.shape[1],xtr.shape[2],1).astype('float32')/255
ytr=tcg(ytr)
yte=tcg(yte)

model = Sequential()
model.add(Flatten())
model.add(Dense(512,activation="relu"))
model.add(Dropout(0.2))
model.add(Dense(10,activation="sigmoid"))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
history = model.fit(xtr,ytr, validation_data=(xte,yte), epochs=10, batch_size=256)

models.save_model(model=model,filepath='E:\ml2\mnist_model')