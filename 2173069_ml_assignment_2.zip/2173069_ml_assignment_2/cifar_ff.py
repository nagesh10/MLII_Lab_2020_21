from tensorflow.keras.datasets import cifar10
from matplotlib import pyplot as plt
from tensorflow.keras.utils import to_categorical as tcg
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense ,Dropout,Flatten
from tensorflow.keras import models

(cfrXtrain,cfrYtrain),(cfrXtest,cfrYtest) = cifar10.load_data()
cfrXtrain=cfrXtrain.reshape(cfrXtrain.shape[0],cfrXtrain.shape[1],cfrXtrain.shape[2],3).astype('float32')/255
cfrXtest=cfrXtest.reshape(cfrXtest.shape[0],cfrXtest.shape[1],cfrXtest.shape[2],3).astype('float32')/255
cfrYtrain=tcg(cfrYtrain)
cfrYtest = tcg(cfrYtest)

from tensorflow.keras.models import Sequential
model = Sequential()
model.add(Flatten())
model.add(Dense(512,activation="relu"))
model.add(Dropout(0.2))
#model.add(Dense(23,activation="relu"))
model.add(Dense(10,activation="softmax"))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
history = model.fit(cfrXtrain,cfrYtrain, validation_data=(cfrXtest,cfrYtest), epochs=15, batch_size=256)

models.save_model(model=model,filepath='E:\ml2\cifar_ff')